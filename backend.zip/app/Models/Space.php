<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Space extends Model
{
    public const MAX_PHOTOS = 10;

    protected $fillable = [
        'user_id',
        'name',
        'description',
        'capacity',
        'zip_code',
        'street',
        'number',
        'complement',
        'neighborhood',
        'city',
        'state',
        'hourly_price',
        'daily_price',
        'opening_hours',
        'availability',
        'amenities',
        'is_active',
    ];

    protected function casts(): array
    {
        // Os preços ficam sem cast de propósito: o resource converte para float (e null continua null).
        return [
            'capacity' => 'integer',
            'opening_hours' => 'array',
            'availability' => 'array',
            'amenities' => 'array',
            'is_active' => 'boolean',
        ];
    }

    /** Busca por nome, rua, bairro ou cidade. */
    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        $term = trim((string) $term);
        if ($term === '') {
            return $query;
        }

        $like = '%'.addcslashes($term, '%_\\').'%';

        return $query->where(function (Builder $where) use ($like) {
            $where->where('name', 'like', $like)
                ->orWhere('street', 'like', $like)
                ->orWhere('neighborhood', 'like', $like)
                ->orWhere('city', 'like', $like);
        });
    }

    /** Admin gerencia todos os locais; os demais usuários, só os próprios. */
    public function manageableBy(User $user): bool
    {
        return $user->isAdmin() || $this->user_id === $user->id;
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function photos(): HasMany
    {
        return $this->hasMany(SpacePhoto::class)->orderBy('position')->orderBy('id');
    }
}
