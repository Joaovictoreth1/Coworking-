<?php

namespace App\Http\Controllers;

use App\Http\Resources\SpaceResource;
use App\Models\Space;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class PublicSpaceController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $spaces = Space::query()
            ->with('photos')
            ->where('is_active', true)
            ->search($request->query('q'))
            ->latest('id')
            ->paginate(12)
            ->withQueryString();

        return SpaceResource::collection($spaces);
    }

    public function show(Space $space): SpaceResource
    {
        abort_unless($space->is_active, 404);

        return new SpaceResource($space->load('photos'));
    }
}
