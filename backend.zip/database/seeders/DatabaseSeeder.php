<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public const PASSWORD = '12345678';
    public const ADMIN_EMAIL = 'admin@teste.com';

    private const USERS = [
        ['Ana Souza', 'ana@teste.com'],
        ['Bruno Lima', 'bruno@teste.com'],
        ['Carla Mendes', 'carla@teste.com'],
    ];

    private const SPACES_PER_USER = 10;

    // [tipo, descrição, capacidade]
    private const TYPES = [
        ['Sala de reunião', 'Sala reservada, ideal para reuniões de equipe, entrevistas e apresentações para clientes.', 8],
        ['Coworking', 'Estações de trabalho compartilhadas em ambiente silencioso e bem iluminado.', 30],
        ['Estúdio de fotografia', 'Estúdio com fundo infinito e iluminação profissional para ensaios e produções.', 12],
        ['Auditório', 'Auditório com palco e sistema de som para palestras, treinamentos e lançamentos.', 120],
        ['Sala de treinamento', 'Sala em formato flexível, boa para cursos e capacitações presenciais.', 25],
        ['Cabine de call', 'Cabine acústica individual para chamadas de vídeo e reuniões rápidas.', 1],
        ['Espaço para eventos', 'Salão amplo para confraternizações, workshops e eventos corporativos.', 80],
        ['Escritório privativo', 'Escritório fechado com mesas, armários e acesso 24 horas para a equipe.', 10],
        ['Estúdio de podcast', 'Estúdio com tratamento acústico, microfones e mesa de som prontos para gravar.', 5],
        ['Sala de workshop', 'Espaço aberto com mesas móveis e lousas, perfeito para dinâmicas em grupo.', 20],
    ];

    // [rua, número, bairro, cidade, UF, CEP]
    private const PLACES = [
        ['Avenida Paulista', '1578', 'Bela Vista', 'São Paulo', 'SP', '01310-200'],
        ['Rua Oscar Freire', '379', 'Jardins', 'São Paulo', 'SP', '01426-001'],
        ['Rua da Consolação', '2302', 'Consolação', 'São Paulo', 'SP', '01302-001'],
        ['Avenida Atlântica', '1702', 'Copacabana', 'Rio de Janeiro', 'RJ', '22021-001'],
        ['Rua Visconde de Pirajá', '550', 'Ipanema', 'Rio de Janeiro', 'RJ', '22410-002'],
        ['Avenida Afonso Pena', '1500', 'Centro', 'Belo Horizonte', 'MG', '30130-921'],
        ['Rua XV de Novembro', '700', 'Centro', 'Curitiba', 'PR', '80020-310'],
        ['Rua dos Andradas', '1234', 'Centro Histórico', 'Porto Alegre', 'RS', '90020-007'],
        ['Avenida Beira Mar Norte', '2100', 'Centro', 'Florianópolis', 'SC', '88015-100'],
        ['Rua Barão de Itapura', '950', 'Centro', 'Dracena', 'SP', '17900-000'],
    ];

    private const AMENITY_IDS = [
        'wifi', 'air_conditioning', 'coffee', 'call_booths', 'meeting_rooms', 'projector',
        'whiteboard', 'printer', 'kitchen', 'parking', 'reception', 'lockers', 'accessibility', 'security',
    ];

    private const HOURLY = [25, 35, 45, 60, 80, 120, 150];

    /**
     * Pode rodar várias vezes: recria/atualiza os usuários (senha padrão 12345678)
     * e só cria os locais de quem ainda não tem nenhum.
     */
    public function run(): void
    {
        $admin = User::updateOrCreate(
            ['email' => self::ADMIN_EMAIL],
            ['name' => 'Admin', 'password' => self::PASSWORD],
        );
        // role não é mass-assignable de propósito (o cadastro público não pode criar admins).
        $admin->forceFill(['role' => User::ROLE_ADMIN])->save();

        foreach (self::USERS as $index => [$name, $email]) {
            $user = User::updateOrCreate(
                ['email' => $email],
                ['name' => $name, 'password' => self::PASSWORD],
            );
            $user->forceFill(['role' => User::ROLE_USER])->save();

            if ($user->spaces()->count() === 0) {
                $this->createSpaces($user, $index);
            }
        }

        $this->command?->info('Admin: '.self::ADMIN_EMAIL.' | Usuários: '
            .implode(', ', array_column(self::USERS, 1)).' | Senha de todos: '.self::PASSWORD);
    }

    private function createSpaces(User $user, int $userIndex): void
    {
        for ($k = 0; $k < self::SPACES_PER_USER; $k++) {
            [$type, $description, $capacity] = self::TYPES[($k + $userIndex * 3) % count(self::TYPES)];
            [$street, $number, $neighborhood, $city, $state, $zip] = self::PLACES[($k * 3 + $userIndex) % count(self::PLACES)];

            $hourly = self::HOURLY[($k + $userIndex) % count(self::HOURLY)];
            // Alterna: só por hora, só por dia, ou os dois
            $mode = ($k + $userIndex) % 3;

            $opening = match ($k % 3) {
                0 => $this->schedule([1, 2, 3, 4, 5], '08:00', '18:00'),
                1 => $this->schedule([1, 2, 3, 4, 5, 6, 0], '07:00', '22:00'),
                default => $this->schedule([1, 2, 3, 4, 5, 6], '09:00', '20:00'),
            };

            // Metade dos locais libera para locação só parte do funcionamento
            $availability = $k % 2 === 0
                ? $opening
                : $this->schedule([1, 2, 3, 4, 5], '09:00', '17:00');

            $amenities = array_slice(
                array_merge(
                    array_slice(self::AMENITY_IDS, $k % count(self::AMENITY_IDS)),
                    array_slice(self::AMENITY_IDS, 0, $k % count(self::AMENITY_IDS)),
                ),
                0,
                3 + ($k % 5),
            );
            if (! in_array('wifi', $amenities, true)) {
                $amenities[] = 'wifi';
            }
            if ($k % 4 === 3) {
                $amenities[] = 'Sala de descompressão';
            }

            $user->spaces()->create([
                'name' => "$type $neighborhood",
                'description' => $description,
                'capacity' => $capacity,
                'zip_code' => $zip,
                'street' => $street,
                'number' => $number,
                'complement' => $k % 2 === 0 ? 'Sala '.(100 + $k * 7) : null,
                'neighborhood' => $neighborhood,
                'city' => $city,
                'state' => $state,
                'hourly_price' => $mode === 1 ? null : $hourly,
                'daily_price' => $mode === 0 ? null : $hourly * 7,
                'opening_hours' => $opening,
                'availability' => $availability,
                'amenities' => $amenities,
                'is_active' => $k !== 6, // um local inativo por usuário
            ]);
        }
    }

    /** @param int[] $enabledDays 0 = domingo ... 6 = sábado */
    private function schedule(array $enabledDays, string $from, string $to): array
    {
        return array_map(fn (int $day) => [
            'day' => $day,
            'enabled' => in_array($day, $enabledDays, true),
            'from' => $from,
            'to' => $to,
        ], [1, 2, 3, 4, 5, 6, 0]);
    }
}
