<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\PublicSpaceController;
use App\Http\Controllers\SpaceController;
use App\Http\Controllers\SpacePhotoController;
use Illuminate\Support\Facades\Route;

Route::prefix('auth')->group(function () {
    Route::post('register', [AuthController::class, 'register'])->middleware('throttle:10,1');
    Route::post('login', [AuthController::class, 'login'])->middleware('throttle:10,1');

    Route::middleware('auth.token')->group(function () {
        Route::get('me', [AuthController::class, 'me']);
        Route::post('logout', [AuthController::class, 'logout']);
    });
});

// Vitrine pública: só locais ativos
Route::get('spaces', [PublicSpaceController::class, 'index'])->middleware('throttle:120,1');
Route::get('spaces/{space}', [PublicSpaceController::class, 'show'])
    ->whereNumber('space')
    ->middleware('throttle:120,1');

// Imagens dos locais (pública: usada direto em <img src>)
Route::get('photos/{photo}', [SpacePhotoController::class, 'show'])
    ->whereNumber('photo')
    ->name('photos.show');

// Painel de locais (admin vê todos; usuário comum, só os seus)
Route::middleware('auth.token')->prefix('admin')->group(function () {
    Route::apiResource('spaces', SpaceController::class);

    Route::post('spaces/{space}/photos', [SpacePhotoController::class, 'store']);
    Route::put('spaces/{space}/photos/order', [SpacePhotoController::class, 'reorder']);
    Route::delete('spaces/{space}/photos/{photo}', [SpacePhotoController::class, 'destroy']);
});
